#include<iostream>
using namespace std;
#include<vector>
#include<queue>

int main()
{
	int n = 7;
	int k = 3;
	vector<int> enemy{ 4,2,4,5,3,3,3,1 };

	priority_queue<int, vector<int>, greater<int>> pq;

	int sum = 0;
	int round = 0;

	for (int i = 0; i < enemy.size(); i++)
	{
		int e = enemy[i];
		pq.push(e);
		if (pq.size() > k)
		{
			sum += pq.top();
			pq.pop();
		}
		if (sum > n)
		{
			round = i;
			break;
		}
		else
		{
			round = enemy.size();
		}
	}
	cout << round << endl;
}